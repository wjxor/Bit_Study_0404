//std.h

#pragma once

#include <stdio.h>
#include <stdlib.h>	//system()
#include <conio.h>  //_getch()
#include <string.h> // strXXX()

#include "app.h"
#include "control.h"
