//control.h

#pragma once

void con_init();
void con_insert();
void con_printall();
void con_select();
void con_update();
void con_delete();
